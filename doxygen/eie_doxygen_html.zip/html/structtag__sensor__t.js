var structtag__sensor__t =
[
    [ "from_channel", "structtag__sensor__t.html#a185a689264ca3fec32b610e2fd53b3b6", null ],
    [ "general_counter", "structtag__sensor__t.html#a2faf1cdface47ade1ec16daea0222319", null ],
    [ "ndil_counter", "structtag__sensor__t.html#ad1a1cb32e07c6a00d4696de61c654938", null ],
    [ "state", "structtag__sensor__t.html#a0b57aa10271a66f3dc936bba1d2f3830", null ],
    [ "threshold", "structtag__sensor__t.html#acebd8775c10986a082360135a65f7efe", null ],
    [ "type_aks_pos_hyst", "structtag__sensor__t.html#a815ba6b5c3f09aebb9891ce8b88ae20b", null ]
];