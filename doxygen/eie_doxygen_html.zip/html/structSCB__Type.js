var structSCB__Type =
[
    [ "ADR", "structSCB__Type.html#a5c0e2e1c7195d4dc09a5ca077c596318", null ],
    [ "AFSR", "structSCB__Type.html#ab9176079ea223dd8902589da91af63a2", null ],
    [ "AIRCR", "structSCB__Type.html#aaec159b48828355cb770049b8b2e8d91", null ],
    [ "BFAR", "structSCB__Type.html#ad49f99b1c83dcab356579af171bfa475", null ],
    [ "CCR", "structSCB__Type.html#a5e1322e27c40bf91d172f9673f205c97", null ],
    [ "CFSR", "structSCB__Type.html#ae6b1e9cde3f94195206c016214cf3936", null ],
    [ "CPUID", "structSCB__Type.html#a30abfea43143a424074f682bd61eace0", null ],
    [ "DFR", "structSCB__Type.html#a1b9a71780ae327f1f337a2176b777618", null ],
    [ "DFSR", "structSCB__Type.html#a415598d9009bb3ffe9f35e03e5a386fe", null ],
    [ "HFSR", "structSCB__Type.html#a87aadbc5e1ffb76d755cf13f4721ae71", null ],
    [ "ICSR", "structSCB__Type.html#a8fec9e122b923822e7f951cd48cf1d47", null ],
    [ "ISAR", "structSCB__Type.html#a130a0c6b3da7f29507a1888afbdce7ee", null ],
    [ "MMFAR", "structSCB__Type.html#a88820a178974aa7b7927155cee5c47ed", null ],
    [ "MMFR", "structSCB__Type.html#ab0dc71239f7d5ffe2e78e683b9530064", null ],
    [ "PFR", "structSCB__Type.html#a00a6649cfac6bbadee51d6ba4c73001d", null ],
    [ "SCR", "structSCB__Type.html#a64a95891ad3e904dd5548112539c1c98", null ],
    [ "SHCSR", "structSCB__Type.html#a04d136e5436e5fa2fb2aaa78a5f86b19", null ],
    [ "SHP", "structSCB__Type.html#a17dc9f83c53cbf7fa249e79a2d2a43f8", null ],
    [ "VTOR", "structSCB__Type.html#aaf388a921a016cae590cfcf1e43b1cdf", null ]
];