var configuration_8h =
[
    [ "ANT_SPI", "configuration_8h.html#a7afd7d310e41a8d27b399b98a0ef5d9a", null ],
    [ "ANT_SSP_FLAGS", "configuration_8h.html#ab4cf6fd05e8c448111102e35b20a9981", null ],
    [ "BLADE_I2C", "configuration_8h.html#ad589611d239463c2cbe8c38dad3c029e", null ],
    [ "BLADE_SPI", "configuration_8h.html#afcc84bc67b5b5507b88ff066992db699", null ],
    [ "BLADE_SPI_FLAGS", "configuration_8h.html#a5d3d1fc66635f78e9172eeb7ee0ff229", null ],
    [ "BLADE_UART", "configuration_8h.html#a27554eed5031295d9c4c56e78ba65787", null ],
    [ "DEBUG_UART", "configuration_8h.html#ace21428290f0e412332701391f825a10", null ],
    [ "SD_SSP_FLAGS", "configuration_8h.html#af618497c049aef08811dabae38300f64", null ],
    [ "PeripheralType", "configuration_8h.html#afc6e623ab05d213bda9b62f3bd823238", [
      [ "SPI0", "configuration_8h.html#afc6e623ab05d213bda9b62f3bd823238a7add1e0588a075d9385b10fcbb2010f4", null ],
      [ "UART", "configuration_8h.html#afc6e623ab05d213bda9b62f3bd823238ab81270ba54ae4586a18415e5a579633d", null ],
      [ "USART0", "configuration_8h.html#afc6e623ab05d213bda9b62f3bd823238aec2fd83f873455753148f632d3b31853", null ],
      [ "USART1", "configuration_8h.html#afc6e623ab05d213bda9b62f3bd823238ac7a8167f83749eed87e3e9fb0dddc6cf", null ],
      [ "USART2", "configuration_8h.html#afc6e623ab05d213bda9b62f3bd823238a096356780f867794998b759a91043b45", null ],
      [ "USART3", "configuration_8h.html#afc6e623ab05d213bda9b62f3bd823238aece01379f8a2c9870feb6210f81c4edd", null ]
    ] ]
];