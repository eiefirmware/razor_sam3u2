var structtag__qt__touch__status__t =
[
    [ "rotor_slider_values", "structtag__qt__touch__status__t.html#ac7046e264cc958d985d39039986d50f4", null ],
    [ "sensor_states", "structtag__qt__touch__status__t.html#a64f4e0bd91d0007a7acf4bf64f88111e", null ]
];