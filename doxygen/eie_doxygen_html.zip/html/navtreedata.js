var NAVTREE =
[
  [ "EiE Firmware", "index.html", [
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"adc12_8c.html",
"antmessage_8h.html",
"eief1-pcb-01_8c.html#a4352a1df62e6397cb4dfb0e66bdec1ff",
"globals_defs_f.html",
"main_8h.html#af384160a5b5e12e6644d05e6d4c451f6",
"sam3u__spi_8h.html#ae39f29d6bc351343e14e6d7aa968ca70",
"structSCB__Type.html#ab9176079ea223dd8902589da91af63a2",
"utilities_8h.html#ae10ca0b5996220c2166505f2aad74fc3"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';