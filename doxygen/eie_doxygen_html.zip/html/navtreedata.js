var NAVTREE =
[
  [ "EiE Firmware", "index.html", [
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"adc12_8c.html",
"antmessage_8h.html",
"debug_8h.html#a5fcae7f5e29d746eeae951628955fb90",
"exceptions_8h.html#a357e85ccf3d98064d7349595399efd33",
"lcd__bitmaps_8c.html#a6290c3c3f8001c9efcedd4835d1eff28",
"mpgl2-ehdw-02_8h.html#a5aa5012ffbd7c6ab8503524432652075",
"sam3u__i2c_8h.html#a5ce24efc25f2649cdce502c6f65072b6",
"structITM__Type.html#ae554433b6f6c4733d222bcb2c75ccb39",
"typedefs_8h.html#af6a258d8f3ee5206d682d799316314b1"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';