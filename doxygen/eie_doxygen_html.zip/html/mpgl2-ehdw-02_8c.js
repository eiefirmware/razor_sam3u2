var mpgl2_ehdw_02_8c =
[
    [ "ClockSetup", "mpgl2-ehdw-02_8c.html#aca735570024c950fd682a96342b84a94", null ],
    [ "GpioSetup", "mpgl2-ehdw-02_8c.html#af88ea80ebfc22fae790de9dd8db74ce9", null ],
    [ "PWMAudioOff", "mpgl2-ehdw-02_8c.html#a59b1b203e1c192f751dc9c05b5f820f7", null ],
    [ "PWMAudioOn", "mpgl2-ehdw-02_8c.html#af9a8f044e0054128c8280a6590bdce56", null ],
    [ "PWMAudioSetFrequency", "mpgl2-ehdw-02_8c.html#a64c014f6542d41483fc686ab82e908a8", null ],
    [ "PWMSetupAudio", "mpgl2-ehdw-02_8c.html#a8b1e7cadaeb381e8ba677cfede840e13", null ],
    [ "SystemSleep", "mpgl2-ehdw-02_8c.html#a9b69fd403c668b7b229fa4e71a77616a", null ],
    [ "SystemTimeCheck", "mpgl2-ehdw-02_8c.html#afdf60ae19c97005e0b80afa7eee2e726", null ],
    [ "SysTickSetup", "mpgl2-ehdw-02_8c.html#aebe279375f0a4bddd6a03a323821ccde", null ],
    [ "WatchDogSetup", "mpgl2-ehdw-02_8c.html#a4352a1df62e6397cb4dfb0e66bdec1ff", null ],
    [ "G_asBspButtonConfigurations", "mpgl2-ehdw-02_8c.html#a488cede447ea21db093f77669cc2378b", null ],
    [ "G_asBspLedConfigurations", "mpgl2-ehdw-02_8c.html#a2fa548b3b2c36d349444d486161a6ce6", null ],
    [ "G_u32ApplicationFlags", "mpgl2-ehdw-02_8c.html#a633c00979917e136ecca6a4c6be2792d", null ],
    [ "G_u32DebugFlags", "mpgl2-ehdw-02_8c.html#a67792c4d9835d5308acde1b059855fc0", null ],
    [ "G_u32SystemFlags", "mpgl2-ehdw-02_8c.html#a8744f5867dbc6c175c029dd7ee5e70af", null ],
    [ "G_u32SystemTime1ms", "mpgl2-ehdw-02_8c.html#aa146f1e0ff7266bfbef420b6fc072f80", null ],
    [ "G_u32SystemTime1s", "mpgl2-ehdw-02_8c.html#a0d1ec61cf0423379d45262186ed60d9c", null ]
];