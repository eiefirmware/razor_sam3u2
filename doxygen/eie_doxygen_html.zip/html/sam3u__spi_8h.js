var sam3u__spi_8h =
[
    [ "SpiConfigurationType", "structSpiConfigurationType.html", "structSpiConfigurationType" ],
    [ "SpiPeripheralType", "structSpiPeripheralType.html", "structSpiPeripheralType" ],
    [ "_SPI_CS_ASSERTED", "sam3u__spi_8h.html#a57950f4d4b957404d2071cf7fdfde35d", null ],
    [ "_SPI_ERROR_INVALID_SPI", "sam3u__spi_8h.html#abd5e5505627541b4943be1dff2ef56d8", null ],
    [ "_SPI_MANUAL_MODE", "sam3u__spi_8h.html#a7430860dfa52bd9e25a030e26bf501f3", null ],
    [ "_SPI_PERIPHERAL_ASSIGNED", "sam3u__spi_8h.html#a0d44b6098da26c078881b0c4b4add95d", null ],
    [ "_SPI_PERIPHERAL_RX", "sam3u__spi_8h.html#ae39f29d6bc351343e14e6d7aa968ca70", null ],
    [ "_SPI_PERIPHERAL_RX_COMPLETE", "sam3u__spi_8h.html#ad35433a84b3104b0926361494454d557", null ],
    [ "_SPI_PERIPHERAL_TX", "sam3u__spi_8h.html#a7e8e6b22fe1abb0442e09d9fe3bba697", null ],
    [ "_SPI_RX_COMPLETE", "sam3u__spi_8h.html#a6912b00546607f02542ab26a6afdf8f1", null ],
    [ "_SPI_TX_COMPLETE", "sam3u__spi_8h.html#aa5ac9a3fa087e9908d2bf25645a9730e", null ],
    [ "SPI_DUMMY", "sam3u__spi_8h.html#adabc44925c93fb09dcbd2e0afba2d251", null ],
    [ "SPI_ERROR_FLAG_MASK", "sam3u__spi_8h.html#a147dcfa9fb52b5a2c436d35936eb868a", null ],
    [ "SPI_TXEMPTY_TIMEOUT", "sam3u__spi_8h.html#adae169ce38a8d1ef2eba0dcc936ba371", null ],
    [ "SpiBitOrderType", "sam3u__spi_8h.html#a292fa01b9e524f81f54eb5a789739d69", [
      [ "SPI_MSB_FIRST", "sam3u__spi_8h.html#a292fa01b9e524f81f54eb5a789739d69a8912f763c0e7854e08dfbe61b7a57cc6", null ],
      [ "SPI_LSB_FIRST", "sam3u__spi_8h.html#a292fa01b9e524f81f54eb5a789739d69a5a6abe145caf9794d5a70e5472ee988f", null ]
    ] ],
    [ "SpiModeType", "sam3u__spi_8h.html#a1fa199d93fe5d28d48bd68e4af073b10", [
      [ "SPI_MASTER", "sam3u__spi_8h.html#a1fa199d93fe5d28d48bd68e4af073b10a84379dc90398ca075038c8d5ee465f6a", null ],
      [ "SPI_SLAVE", "sam3u__spi_8h.html#a1fa199d93fe5d28d48bd68e4af073b10abc98c1546fe12d3fceb1f86cf670faa9", null ]
    ] ],
    [ "SpiRxStatusType", "sam3u__spi_8h.html#aec36048014a48ff20b07431daeb12c6b", [
      [ "SPI_RX_EMPTY", "sam3u__spi_8h.html#aec36048014a48ff20b07431daeb12c6ba498ef0657765b736d7837de729f720ff", null ],
      [ "SPI_RX_WAITING", "sam3u__spi_8h.html#aec36048014a48ff20b07431daeb12c6ba4e37e0f6fabb1cd8bc37fe96ce27e33a", null ],
      [ "SPI_RX_RECEIVING", "sam3u__spi_8h.html#aec36048014a48ff20b07431daeb12c6badf116d7e83cc79ce70d7c63a67ef096e", null ],
      [ "SPI_RX_COMPLETE", "sam3u__spi_8h.html#aec36048014a48ff20b07431daeb12c6bac2493b9c81ccd062e4e094fe8ad9349c", null ],
      [ "SPI_RX_TIMEOUT", "sam3u__spi_8h.html#aec36048014a48ff20b07431daeb12c6bac2e0dc3ff25d49066faab3315f422669", null ],
      [ "SPI_RX_INVALID", "sam3u__spi_8h.html#aec36048014a48ff20b07431daeb12c6ba29d0da7b24fb9eae19d22344514719b1", null ]
    ] ],
    [ "SPI0_IrqHandler", "sam3u__spi_8h.html#a649e0c1566b358c4ceef841110102729", null ],
    [ "SpiInitialize", "sam3u__spi_8h.html#aba925e3f2f6db724cc7c658aa2194666", null ],
    [ "SpiManualMode", "sam3u__spi_8h.html#ac2b83008a53b47d3aa3f32c6daa1e526", null ],
    [ "SpiQueryReceiveStatus", "sam3u__spi_8h.html#a53b41283a1472f154684a0bae059c3ae", null ],
    [ "SpiReadByte", "sam3u__spi_8h.html#a4199476ce7e4e7e6053c6c83fd2c8b05", null ],
    [ "SpiReadData", "sam3u__spi_8h.html#a4035042dbf5e554c4711edd370cf8708", null ],
    [ "SpiRelease", "sam3u__spi_8h.html#a2036fe5e9c7a5cd772d7167fa3db221b", null ],
    [ "SpiRequest", "sam3u__spi_8h.html#a27f74727d3ee22c332313c292c57a5d7", null ],
    [ "SpiRunActiveState", "sam3u__spi_8h.html#a32acf207c4bb9895665793e7d6a78a6e", null ],
    [ "SpiWriteByte", "sam3u__spi_8h.html#a48c914e261ba63bf6f8c0c1b616ca785", null ],
    [ "SpiWriteData", "sam3u__spi_8h.html#a861fb1e714f39349aa1c45a62ca73d92", null ]
];