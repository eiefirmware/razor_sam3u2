var structButtonStatusType =
[
    [ "bDebounceActive", "structButtonStatusType.html#a8eff1883c9cc2ae385a0649f811ee14f", null ],
    [ "bNewPressFlag", "structButtonStatusType.html#a063d825a359b5a9dd7d4534c8ab41026", null ],
    [ "eCurrentState", "structButtonStatusType.html#a68374581f83822e5df7e47f580d9d4e8", null ],
    [ "eNewState", "structButtonStatusType.html#ab4738616241b983ca6fa718f4fdfad17", null ],
    [ "u32DebounceTimeStart", "structButtonStatusType.html#ad6e28a0b0826a577c06550ea0561a520", null ],
    [ "u32TimeStamp", "structButtonStatusType.html#a5c90495f986004ae8c2cce2f94cc87e9", null ]
];