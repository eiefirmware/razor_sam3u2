var sam3u__i2c_8h =
[
    [ "TwiPeripheralType", "structTwiPeripheralType.html", "structTwiPeripheralType" ],
    [ "TwiMessageQueueType", "structTwiMessageQueueType.html", "structTwiMessageQueueType" ],
    [ "_TWI_ERROR_INTERRUPT", "sam3u__i2c_8h.html#a23510afe0444a9ce1ace72209d7cdb74", null ],
    [ "_TWI_ERROR_NACK", "sam3u__i2c_8h.html#a4bed9bade709f684e2af152553859392", null ],
    [ "_TWI_ERROR_RX_TIMEOUT", "sam3u__i2c_8h.html#a5ce24efc25f2649cdce502c6f65072b6", null ],
    [ "_TWI_ERROR_TX_MSG_SYNC", "sam3u__i2c_8h.html#a30bede2a3f2b1a7b3dc834626dd393d9", null ],
    [ "_TWI_INIT_MODE", "sam3u__i2c_8h.html#ab8686aacc9c63be4fb861fde9eb65dc4", null ],
    [ "_TWI_RECEIVING", "sam3u__i2c_8h.html#ac30900ad2015982815785982b03f7935", null ],
    [ "_TWI_TRANS_NOT_COMP", "sam3u__i2c_8h.html#a1c83205720be65c36d85e336242a3a58", null ],
    [ "_TWI_TRANSMITTING", "sam3u__i2c_8h.html#a680b41941f9727a6bdf4211f68324a69", null ],
    [ "TWI_ERROR_FLAG_MASK", "sam3u__i2c_8h.html#a421e1ab8d3d20d6030a70c6023ded300", null ],
    [ "U32_RX_TIMEOUT_MS", "sam3u__i2c_8h.html#a4c8f72e434843550ca6ac66b8ace4557", null ],
    [ "U8_NEXT_TRANSFER_DELAY_MS", "sam3u__i2c_8h.html#aebbbe04f990963e6885cac9aef2e3ea8", null ],
    [ "U8_TWI_MSG_BUFFER_SIZE", "sam3u__i2c_8h.html#ab885278934a21907a1c69919a73cbe47", null ],
    [ "TwiDirectionType", "sam3u__i2c_8h.html#ab4240a0820f4f6e1543a7d988fe4d73f", [
      [ "TWI_EMPTY", "sam3u__i2c_8h.html#ab4240a0820f4f6e1543a7d988fe4d73fa68ece9aa65cd3f49984ebb2f930578da", null ],
      [ "TWI_WRITE", "sam3u__i2c_8h.html#ab4240a0820f4f6e1543a7d988fe4d73faabe9d2ee52d1644f355020fae1a71dc7", null ],
      [ "TWI_READ", "sam3u__i2c_8h.html#ab4240a0820f4f6e1543a7d988fe4d73fadbff79e8154b1f3059addaf4b5047ba8", null ]
    ] ],
    [ "TwiStopType", "sam3u__i2c_8h.html#ac71352b0f5662444c36a9b26aea890f2", [
      [ "TWI_STOP", "sam3u__i2c_8h.html#ac71352b0f5662444c36a9b26aea890f2a98a073cf7994dedf2a0b2b81c41a335a", null ],
      [ "TWI_NO_STOP", "sam3u__i2c_8h.html#ac71352b0f5662444c36a9b26aea890f2aa6f59cdb2978a0cb230536b5829d8bbc", null ],
      [ "TWI_NA", "sam3u__i2c_8h.html#ac71352b0f5662444c36a9b26aea890f2a1c910b19773ce14b913f006f7250576e", null ]
    ] ],
    [ "TWI0_IrqHandler", "sam3u__i2c_8h.html#a21b3060c7200be587333cb5db94dd4e8", null ],
    [ "TwiInitialize", "sam3u__i2c_8h.html#a80c9332ea2b05744fc49bb2c0c2222a8", null ],
    [ "TwiManualMode", "sam3u__i2c_8h.html#a31a13eee3dc2f03532a204e4ff23f0f6", null ],
    [ "TwiReadData", "sam3u__i2c_8h.html#a2640b95b2139d70c075faf6e79f10dbc", null ],
    [ "TwiRunActiveState", "sam3u__i2c_8h.html#a0768c5d84e355591884f89c5278a202b", null ],
    [ "TwiWriteData", "sam3u__i2c_8h.html#ae6c3b9961ba3782ce81a03d4880e69e0", null ]
];