var structLedControlType =
[
    [ "eCurrentDuty", "structLedControlType.html#af3716d3a20359fc32353e76bf5bdb6eb", null ],
    [ "eMode", "structLedControlType.html#a75189baaedce42a33916c58cd4f8259d", null ],
    [ "eRate", "structLedControlType.html#a11acb17ed0b5b0430a6f2c1391cd6111", null ],
    [ "u16Count", "structLedControlType.html#aceade36f136a3b4c30c3a467f7c98b50", null ]
];