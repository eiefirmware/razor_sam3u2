var structAntMessageResponseType =
[
    [ "u8Channel", "structAntMessageResponseType.html#ab76fdb9425184ad2e069d74de963e98a", null ],
    [ "u8MessageNumber", "structAntMessageResponseType.html#a27c0fd9b5c8a003531e7a118117c22ed", null ],
    [ "u8ResponseCode", "structAntMessageResponseType.html#ae1ad59beb4d4b222736f5d661782135e", null ]
];