var structTwiPeripheralType =
[
    [ "pBaseAddress", "structTwiPeripheralType.html#a1aba4642e7f4ecfae56c17353e45f2c8", null ],
    [ "pTransmitBuffer", "structTwiPeripheralType.html#a0c717b316d1f1c2d2329053922c7c39e", null ],
    [ "u32PrivateFlags", "structTwiPeripheralType.html#a92ea6e492759d5d2e4b46c21ed300e4c", null ]
];