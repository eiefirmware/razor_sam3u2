var structPixelAddressType =
[
    [ "u16PixelColumnAddress", "structPixelAddressType.html#aa76a98436d0d20de251e23d6cdba383a", null ],
    [ "u16PixelRowAddress", "structPixelAddressType.html#a92996fffcec378613cf74c88dc7849d3", null ]
];