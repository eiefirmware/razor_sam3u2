var structSpiPeripheralType =
[
    [ "eBitOrder", "structSpiPeripheralType.html#aa371d15e095f4b7f5055baa02d47f218", null ],
    [ "eSpiMode", "structSpiPeripheralType.html#a2196a8268f09468080608ed3dc0b136e", null ],
    [ "pBaseAddress", "structSpiPeripheralType.html#a48410e7421ebf8e3e56471f85e4ee2e5", null ],
    [ "pCsGpioAddress", "structSpiPeripheralType.html#a2d4fa184a4ad668dfdff08c6b61247e0", null ],
    [ "ppu8RxNextByte", "structSpiPeripheralType.html#a53c9884c7bae33b79a958f98fc0549dd", null ],
    [ "psTransmitBuffer", "structSpiPeripheralType.html#ab050493c2ee33d0b4525999076d8bbe6", null ],
    [ "pu8CurrentTxData", "structSpiPeripheralType.html#a37d6782344fe4a6866def37b345f3361", null ],
    [ "pu8RxBuffer", "structSpiPeripheralType.html#a90b4f2c98ae95b888a185b7d842f52b5", null ],
    [ "u16RxBufferSize", "structSpiPeripheralType.html#ab7fc4919ed52c499554e6a111ff03385", null ],
    [ "u16RxBytes", "structSpiPeripheralType.html#ab68f3ebf343dd380a0394c213eb653f4", null ],
    [ "u32CsPin", "structSpiPeripheralType.html#a746468875c8fa523de187aa9cba2f375", null ],
    [ "u32CurrentTxBytesRemaining", "structSpiPeripheralType.html#aba7dde0373af6515f1ea1fb3ca60b0b7", null ],
    [ "u32PrivateFlags", "structSpiPeripheralType.html#a92ea6e492759d5d2e4b46c21ed300e4c", null ],
    [ "u8Pad", "structSpiPeripheralType.html#a095538a86db156105d1920856af97f8b", null ],
    [ "u8PeripheralId", "structSpiPeripheralType.html#a6d47610e17bac3adaae644e2f1abd6ce", null ]
];