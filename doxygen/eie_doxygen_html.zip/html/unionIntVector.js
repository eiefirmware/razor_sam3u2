var unionIntVector =
[
    [ "__fun", "unionIntVector.html#ac27d9fd73c326d697b5d73381d9f437b", null ],
    [ "__ptr", "unionIntVector.html#a048f06ea03d2c16f7368d2ec9939341c", null ]
];