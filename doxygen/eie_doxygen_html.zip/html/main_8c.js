var main_8c =
[
    [ "kill_x_cycles", "main_8c.html#a3aeeae0b505f2e5839a64737e8e15570", null ],
    [ "main", "main_8c.html#a6288eba0f8e8ad3ab1544ad731eb7667", null ],
    [ "G_u32ApplicationFlags", "main_8c.html#a633c00979917e136ecca6a4c6be2792d", null ],
    [ "G_u32SystemFlags", "main_8c.html#a8744f5867dbc6c175c029dd7ee5e70af", null ],
    [ "G_u32SystemTime1ms", "main_8c.html#aa146f1e0ff7266bfbef420b6fc072f80", null ],
    [ "G_u32SystemTime1s", "main_8c.html#a0d1ec61cf0423379d45262186ed60d9c", null ]
];