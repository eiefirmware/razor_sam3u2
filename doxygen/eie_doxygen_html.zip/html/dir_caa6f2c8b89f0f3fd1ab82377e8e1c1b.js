var dir_caa6f2c8b89f0f3fd1ab82377e8e1c1b =
[
    [ "include", "dir_672a85f87a0057168b63390db844f43d.html", "dir_672a85f87a0057168b63390db844f43d" ],
    [ "libqtouch.h", "libqtouch_8h_source.html", null ]
];