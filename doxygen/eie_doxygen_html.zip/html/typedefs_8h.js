var typedefs_8h =
[
    [ "PinConfigurationType", "structPinConfigurationType.html", "structPinConfigurationType" ],
    [ "fnCode_type", "typedefs_8h.html#a8ad064e9f68a73ffceb7adad746b3d81", null ],
    [ "fnCode_u16_type", "typedefs_8h.html#adf5be79d6f4ab4b5f1364599ad961d96", null ],
    [ "s16", "typedefs_8h.html#a2e9bf6983da73775aa86158c825bf777", null ],
    [ "s32", "typedefs_8h.html#a584ab8b1fe53a7874ffa10b1f0c54ef4", null ],
    [ "s8", "typedefs_8h.html#a151f780fb455885061d3b77ec1c90c03", null ],
    [ "sc16", "typedefs_8h.html#ae847bd4779c434029761bec8b0935514", null ],
    [ "sc32", "typedefs_8h.html#a0638a9182b1734497dbeccda3b4ead18", null ],
    [ "sc8", "typedefs_8h.html#ad0034305fecfbc44db47d5b7c785c2a6", null ],
    [ "u16", "typedefs_8h.html#ae227e4203eabbdc32d5733f67b423bd0", null ],
    [ "u32", "typedefs_8h.html#a59725e3d58451855ffcb421c44ec9fbd", null ],
    [ "u8", "typedefs_8h.html#aa0c372bc7b65f22c3be06a7c6ab21935", null ],
    [ "uc16", "typedefs_8h.html#a4ecc19884f412eba40b65d44a0509d8b", null ],
    [ "uc32", "typedefs_8h.html#ac2df2388409fba1b0ded493daf390e47", null ],
    [ "uc8", "typedefs_8h.html#a80cd0c581ba4b5fa2c23b41ffa404235", null ],
    [ "bool", "typedefs_8h.html#af6a258d8f3ee5206d682d799316314b1", [
      [ "FALSE", "typedefs_8h.html#af6a258d8f3ee5206d682d799316314b1aa1e095cc966dbecf6a0d8aad75348d1a", null ],
      [ "TRUE", "typedefs_8h.html#af6a258d8f3ee5206d682d799316314b1aa82764c3079aea4e60c80e45befbb839", null ]
    ] ],
    [ "ErrorStatus", "typedefs_8h.html#a8333b96c67f83cba354b3407fcbb6ee8", [
      [ "ERROR", "typedefs_8h.html#a8333b96c67f83cba354b3407fcbb6ee8a2fd6f336d08340583bd620a7f5694c90", null ],
      [ "SUCCESS", "typedefs_8h.html#a8333b96c67f83cba354b3407fcbb6ee8ac7f69f7c9e5aea9b8f54cf02870e2bf8", null ]
    ] ],
    [ "GpioActiveType", "typedefs_8h.html#a6e9280ee71365497a2b05b768c107d7e", [
      [ "ACTIVE_LOW", "typedefs_8h.html#a6e9280ee71365497a2b05b768c107d7ea43ad983a1a6a3c04a137ec0471cdfe85", null ],
      [ "ACTIVE_HIGH", "typedefs_8h.html#a6e9280ee71365497a2b05b768c107d7eafe240f1952811db0c18b4355fb28190f", null ]
    ] ],
    [ "PortOffsetType", "typedefs_8h.html#a157c82d753747a4d2b536691e3a36c53", [
      [ "PORTA", "typedefs_8h.html#a157c82d753747a4d2b536691e3a36c53ae3201f6e0d0c1e138c60903276bb3859", null ],
      [ "PORTB", "typedefs_8h.html#a157c82d753747a4d2b536691e3a36c53ae51dea4a37f3e2ede7ba6f27c563f6a4", null ]
    ] ]
];