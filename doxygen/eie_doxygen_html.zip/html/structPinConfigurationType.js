var structPinConfigurationType =
[
    [ "eActiveState", "structPinConfigurationType.html#a708cab49e13e496146a86988dffc53e6", null ],
    [ "ePort", "structPinConfigurationType.html#a6b194af58bd49d047765b83eb1a78b74", null ],
    [ "u32BitPosition", "structPinConfigurationType.html#a537228b5cb7dd44b059610453a4cb31c", null ]
];