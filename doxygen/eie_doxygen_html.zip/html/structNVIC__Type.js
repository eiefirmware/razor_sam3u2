var structNVIC__Type =
[
    [ "IABR", "structNVIC__Type.html#ac8694e172f431db09b5d570993da3917", null ],
    [ "ICER", "structNVIC__Type.html#af458bc93cfb899fc1c77c5d1f39dde88", null ],
    [ "ICPR", "structNVIC__Type.html#a8165d9a8c0090021e56bbe91c2c44667", null ],
    [ "IP", "structNVIC__Type.html#a38c377984f751265667317981f101bb4", null ],
    [ "ISER", "structNVIC__Type.html#a0bf79013b539f9f929c75bd50f8ec67d", null ],
    [ "ISPR", "structNVIC__Type.html#ab39acf254b485e3ad71b18aa9f1ca594", null ],
    [ "RESERVED0", "structNVIC__Type.html#ac881b676be4d9659951f43c2fccb34b4", null ],
    [ "RESERVED2", "structNVIC__Type.html#a86dfd6bf6c297be163d078945f67e8b6", null ],
    [ "RESERVED3", "structNVIC__Type.html#a3371761ff5e69fb1b6b3c2c3b4d69b18", null ],
    [ "RESERVED4", "structNVIC__Type.html#a0c75e6c517dc8e5596ffa3ef6285c232", null ],
    [ "RESERVED5", "structNVIC__Type.html#a77017390737a14d5eb4cdb41f0aa3dce", null ],
    [ "RSERVED1", "structNVIC__Type.html#ab993fe7f0b489b30bc677ccf53426a92", null ],
    [ "STIR", "structNVIC__Type.html#a471c399bb79454dcdfb342a31a5684ae", null ]
];