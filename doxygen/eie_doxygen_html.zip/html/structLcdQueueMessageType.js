var structLcdQueueMessageType =
[
    [ "eMessageType", "structLcdQueueMessageType.html#ad0112acf54ec2602cbd0bf789b66bed4", null ],
    [ "pu8Data", "structLcdQueueMessageType.html#aa75a4f7a868fc05670c078697127a2b3", null ],
    [ "u16Length", "structLcdQueueMessageType.html#a9e81ffe8770405ed16cc804c613dee7c", null ]
];