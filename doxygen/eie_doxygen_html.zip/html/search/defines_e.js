var searchData=
[
  ['pclk_5fvalue',['PCLK_VALUE',['../eief1-pcb-01_8h.html#a29910740c11df3213cd16779116d9063',1,'PCLK_VALUE():&#160;eief1-pcb-01.h'],['../mpgl2-ehdw-02_8h.html#a29910740c11df3213cd16779116d9063',1,'PCLK_VALUE():&#160;mpgl2-ehdw-02.h']]],
  ['peripheral_5fdivider',['PERIPHERAL_DIVIDER',['../eief1-pcb-01_8h.html#ac5bc41f369eb2a4720c7e544596d2548',1,'PERIPHERAL_DIVIDER():&#160;eief1-pcb-01.h'],['../mpgl2-ehdw-02_8h.html#ac5bc41f369eb2a4720c7e544596d2548',1,'PERIPHERAL_DIVIDER():&#160;mpgl2-ehdw-02.h']]],
  ['pllack_5fvalue',['PLLACK_VALUE',['../eief1-pcb-01_8h.html#a27ea607d0a7d655b6b3e10947dc73b64',1,'PLLACK_VALUE():&#160;eief1-pcb-01.h'],['../mpgl2-ehdw-02_8h.html#a27ea607d0a7d655b6b3e10947dc73b64',1,'PLLACK_VALUE():&#160;mpgl2-ehdw-02.h']]],
  ['priority_5fregisters',['PRIORITY_REGISTERS',['../interrupts_8h.html#a83fbe97e3993436ac8679d7da7c14aed',1,'interrupts.h']]]
];
