var searchData=
[
  ['qtouch_5fdebug_5fprint_5fperiod',['QTOUCH_DEBUG_PRINT_PERIOD',['../captouch_8h.html#ac541c5ce49cfbe37af2afce5aeff5707',1,'captouch.h']]],
  ['qtouch_5fmeasurement_5ftime_5fms',['QTOUCH_MEASUREMENT_TIME_MS',['../captouch_8h.html#a0875ccbcfe7f9a0ad74d2246172ae55d',1,'captouch.h']]],
  ['qtouch_5fmeasurement_5ftimeout',['QTOUCH_MEASUREMENT_TIMEOUT',['../captouch_8h.html#a81d8f5ab588468b74cdea28714c5676d',1,'captouch.h']]]
];
