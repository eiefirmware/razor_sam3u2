var searchData=
[
  ['coredebug_5ftype',['CoreDebug_Type',['../structCoreDebug__Type.html',1,'']]]
];
