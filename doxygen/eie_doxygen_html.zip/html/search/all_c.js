var searchData=
[
  ['nonmaskableint_5firqn',['NonMaskableInt_IRQn',['../interrupts_8h.html#a666eb0caeb12ec0e281415592ae89083ade177d9c70c89e084093024b932a4e30',1,'interrupts.h']]],
  ['number_5fapplications',['NUMBER_APPLICATIONS',['../main_8h.html#ade12517e47f32c03f37f4bf7fb37ca1c',1,'main.h']]],
  ['number_5fascii_5fto_5fdec',['NUMBER_ASCII_TO_DEC',['../utilities_8h.html#aaaa8a025d4b928fe46a24240c7b7b71c',1,'utilities.h']]],
  ['numbertoascii',['NumberToAscii',['../utilities_8c.html#aba2629a9c074c243555a6f1eb62317c4',1,'NumberToAscii(u32 u32Number_, u8 *pu8AsciiString_):&#160;utilities.c'],['../utilities_8h.html#aba2629a9c074c243555a6f1eb62317c4',1,'NumberToAscii(u32 u32Number_, u8 *pu8AsciiString_):&#160;utilities.c']]],
  ['nvic',['NVIC',['../core__cm3_8h.html#ac8e97e8ce56ae9f57da1363a937f8a17',1,'core_cm3.h']]],
  ['nvic_5faircr_5fendianess',['NVIC_AIRCR_ENDIANESS',['../core__cm3_8h.html#a2b09738a6dbbef976ba64156c3b5c5a3',1,'core_cm3.h']]],
  ['nvic_5faircr_5fvectkey',['NVIC_AIRCR_VECTKEY',['../core__cm3_8h.html#a2f8cb12ddfff6c13cf3fefd1c7d490f4',1,'core_cm3.h']]],
  ['nvic_5fbase',['NVIC_BASE',['../core__cm3_8h.html#aa0288691785a5f868238e0468b39523d',1,'core_cm3.h']]],
  ['nvic_5fsysresetreq',['NVIC_SYSRESETREQ',['../core__cm3_8h.html#a461d3b604dbeec9525775a7ad7ee501c',1,'core_cm3.h']]],
  ['nvic_5ftype',['NVIC_Type',['../structNVIC__Type.html',1,'']]],
  ['nvic_5fvectreset',['NVIC_VECTRESET',['../core__cm3_8h.html#a5baecd2b24d7ca2fb850c7ffc05799ac',1,'core_cm3.h']]]
];
