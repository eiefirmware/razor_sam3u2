var searchData=
[
  ['errorstatus',['ErrorStatus',['../structErrorStatus.html',1,'']]]
];
