var searchData=
[
  ['spibitordertype',['SpiBitOrderType',['../sam3u__spi_8h.html#a292fa01b9e524f81f54eb5a789739d69',1,'sam3u_spi.h']]],
  ['spimodetype',['SpiModeType',['../sam3u__spi_8h.html#a1fa199d93fe5d28d48bd68e4af073b10',1,'sam3u_spi.h']]],
  ['spirxstatustype',['SpiRxStatusType',['../sam3u__spi_8h.html#aec36048014a48ff20b07431daeb12c6b',1,'sam3u_spi.h']]],
  ['sspbitordertype',['SspBitOrderType',['../sam3u__ssp_8h.html#a348e1f3c063e297e9359badeda6b420d',1,'sam3u_ssp.h']]],
  ['sspmodetype',['SspModeType',['../sam3u__ssp_8h.html#add58c530ced3f2d039a19d990c5633ac',1,'sam3u_ssp.h']]],
  ['ssprxstatustype',['SspRxStatusType',['../sam3u__ssp_8h.html#ae06eee04d7c0a6c01a1c9bfc6ff97935',1,'sam3u_ssp.h']]]
];
