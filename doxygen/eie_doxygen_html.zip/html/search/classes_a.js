var searchData=
[
  ['twimessagequeuetype',['TwiMessageQueueType',['../structTwiMessageQueueType.html',1,'']]],
  ['twiperipheraltype',['TwiPeripheralType',['../structTwiPeripheralType.html',1,'']]]
];
