var searchData=
[
  ['firmware_5fversion',['FIRMWARE_VERSION',['../main_8h.html#aa14dc39d52ab121ceb570f1a265385e0',1,'main.h']]]
];
