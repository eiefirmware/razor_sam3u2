var searchData=
[
  ['heartbeat_5foff',['HEARTBEAT_OFF',['../eief1-pcb-01_8h.html#a49a7c18670756657715dd118f3a25bc0',1,'HEARTBEAT_OFF():&#160;eief1-pcb-01.h'],['../mpgl2-ehdw-02_8h.html#a49a7c18670756657715dd118f3a25bc0',1,'HEARTBEAT_OFF():&#160;mpgl2-ehdw-02.h']]],
  ['heartbeat_5fon',['HEARTBEAT_ON',['../eief1-pcb-01_8h.html#ad1add0383083772c5710a5d90b86bace',1,'HEARTBEAT_ON():&#160;eief1-pcb-01.h'],['../mpgl2-ehdw-02_8h.html#ad1add0383083772c5710a5d90b86bace',1,'HEARTBEAT_ON():&#160;mpgl2-ehdw-02.h']]]
];
