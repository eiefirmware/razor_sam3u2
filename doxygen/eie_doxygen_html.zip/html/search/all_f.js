var searchData=
[
  ['querymessagestatus',['QueryMessageStatus',['../messaging_8c.html#a92351af765311e97b2accc2703357a60',1,'QueryMessageStatus(u32 u32Token_):&#160;messaging.c'],['../messaging_8h.html#a92351af765311e97b2accc2703357a60',1,'QueryMessageStatus(u32 u32Token_):&#160;messaging.c']]],
  ['queuemessage',['QueueMessage',['../messaging_8c.html#a2118aea9d5822d83de3837aca50eb524',1,'QueueMessage(MessageType **ppsTargetTxBuffer_, u32 u32MessageSize_, u8 *pu8MessageData_):&#160;messaging.c'],['../messaging_8h.html#a2a829ace92aa39d7c6f3667f68bab695',1,'QueueMessage(MessageType **ppeTargetTxBuffer_, u32 u32MessageSize_, u8 *pu8MessageData_):&#160;messaging.c']]]
];
