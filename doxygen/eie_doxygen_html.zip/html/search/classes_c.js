var searchData=
[
  ['tag_5fqt_5ftouch_5flib_5fconfig_5fdata_5ft',['tag_qt_touch_lib_config_data_t',['../structtag__qt__touch__lib__config__data__t.html',1,'']]],
  ['tag_5fqt_5ftouch_5flib_5fmeasure_5fdata_5ft',['tag_qt_touch_lib_measure_data_t',['../structtag__qt__touch__lib__measure__data__t.html',1,'']]],
  ['tag_5fqt_5ftouch_5fstatus_5ft',['tag_qt_touch_status_t',['../structtag__qt__touch__status__t.html',1,'']]],
  ['tag_5fsensor_5ft',['tag_sensor_t',['../structtag__sensor__t.html',1,'']]],
  ['twimessagequeuetype',['TwiMessageQueueType',['../structTwiMessageQueueType.html',1,'']]],
  ['twiperipheraltype',['TwiPeripheralType',['../structTwiPeripheralType.html',1,'']]]
];
