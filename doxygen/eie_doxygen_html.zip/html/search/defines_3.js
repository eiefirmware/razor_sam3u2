var searchData=
[
  ['cclk_5fvalue',['CCLK_VALUE',['../eief1-pcb-01_8h.html#a61d3b2c40b3124ab4c7efce94a7d81e2',1,'eief1-pcb-01.h']]],
  ['channel_5fid_5fnot_5fset',['CHANNEL_ID_NOT_SET',['../antdefines_8h.html#a2ece855dff97f8acea68c06d7a75abf6',1,'antdefines.h']]],
  ['channel_5fin_5fwrong_5fstate',['CHANNEL_IN_WRONG_STATE',['../antdefines_8h.html#ae63dd1e4e2a57a5d8a1e6927c9a6fad4',1,'antdefines.h']]],
  ['channel_5fnot_5fopened',['CHANNEL_NOT_OPENED',['../antdefines_8h.html#a831f38de81c3ee18dc3d6d58a28469c4',1,'antdefines.h']]],
  ['coredebug',['CoreDebug',['../core__cm3_8h.html#ab6e30a2b802d9021619dbb0be7f5d63d',1,'core_cm3.h']]],
  ['coredebug_5fbase',['CoreDebug_BASE',['../core__cm3_8h.html#a680604dbcda9e9b31a1639fcffe5230b',1,'core_cm3.h']]],
  ['coredebug_5fdemcr_5ftrcena',['CoreDebug_DEMCR_TRCENA',['../core__cm3_8h.html#a806e775f7ac4bf19dd39b4075bd5a8a5',1,'core_cm3.h']]],
  ['cpu_5fdivider',['CPU_DIVIDER',['../eief1-pcb-01_8h.html#a97f2421fa5a488fa007c4698abb2159f',1,'eief1-pcb-01.h']]]
];
