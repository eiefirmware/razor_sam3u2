var searchData=
[
  ['osc_5fvalue',['OSC_VALUE',['../eief1-pcb-01_8h.html#a02682feb445d88186d6d40048f85ae88',1,'OSC_VALUE():&#160;eief1-pcb-01.h'],['../mpgl2-ehdw-02_8h.html#a02682feb445d88186d6d40048f85ae88',1,'OSC_VALUE():&#160;mpgl2-ehdw-02.h']]]
];
