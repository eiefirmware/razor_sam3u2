var timer_8h =
[
    [ "TimerChannelType", "timer_8h.html#a53477707067ffd9d787cbafcb2adefcc", [
      [ "TIMER0_CHANNEL0", "timer_8h.html#a53477707067ffd9d787cbafcb2adefccad106773fb759a7d48c120f5d0f23e353", null ],
      [ "TIMER0_CHANNEL1", "timer_8h.html#a53477707067ffd9d787cbafcb2adefcca2991e35548488757ea5f97f0a92b93a8", null ],
      [ "TIMER0_CHANNEL2", "timer_8h.html#a53477707067ffd9d787cbafcb2adefcca8061fc35a237aff63e627e24e5d0b69d", null ]
    ] ],
    [ "TimerAssignCallback", "timer_8h.html#a1a12432eadd687c8e1ad8b3332098293", null ],
    [ "TimerGetTime", "timer_8h.html#ab28ea02477b08fa203d17146b6af4bb4", null ],
    [ "TimerInitialize", "timer_8h.html#a647e04d964a0a16f283dfa9dedb611c6", null ],
    [ "TimerRunActiveState", "timer_8h.html#a8d4081a1491a3634d1c762f7c8460328", null ],
    [ "TimerSet", "timer_8h.html#a6d99a27dd3918ff8f69ba2e67ab8b493", null ],
    [ "TimerStart", "timer_8h.html#a70d635bac016d65e5031b1eab2739cae", null ],
    [ "TimerStop", "timer_8h.html#a636dfe0f268036a65dd8497ea146f1c6", null ]
];