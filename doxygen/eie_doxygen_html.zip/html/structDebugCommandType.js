var structDebugCommandType =
[
    [ "DebugFunction", "structDebugCommandType.html#ad693cabfff15972ad9fedbbc441d81e2", null ],
    [ "pu8CommandName", "structDebugCommandType.html#a89416f522220958d8e451d29a76aa637", null ]
];