var captouch_8h =
[
    [ "QTOUCH_DEBUG_PRINT_PERIOD", "captouch_8h.html#ac541c5ce49cfbe37af2afce5aeff5707", null ],
    [ "QTOUCH_MEASUREMENT_TIME_MS", "captouch_8h.html#a0875ccbcfe7f9a0ad74d2246172ae55d", null ],
    [ "QTOUCH_MEASUREMENT_TIMEOUT", "captouch_8h.html#a81d8f5ab588468b74cdea28714c5676d", null ],
    [ "SliderNumberType", "captouch_8h.html#ab9cf6cabdb228bf4132cd6ab249dd481", [
      [ "SLIDER0", "captouch_8h.html#ab9cf6cabdb228bf4132cd6ab249dd481a15443abc0adbc16af6c8fe91308d8e3e", null ],
      [ "SLIDER1", "captouch_8h.html#ab9cf6cabdb228bf4132cd6ab249dd481a56958a76355517a9009f0785df9d9f8a", null ]
    ] ],
    [ "CaptouchCurrentHSlidePosition", "captouch_8h.html#af023afe52ae5995776797bc77a7c53a5", null ],
    [ "CaptouchCurrentVSlidePosition", "captouch_8h.html#a05197b02c441eb6eadef1ef094dd56e9", null ],
    [ "CapTouchInitialize", "captouch_8h.html#ad549ea879c9ea33b499455fcfbbd3598", null ],
    [ "CapTouchOff", "captouch_8h.html#a58fac143e9a21e91e7b789888eeec3a1", null ],
    [ "CapTouchOn", "captouch_8h.html#ac0dcd1817bb72731cd0e89f1d16f2c71", null ],
    [ "CapTouchRunActiveState", "captouch_8h.html#a89acaf27b5e59d994e64ff5c526ff2e6", null ],
    [ "CapTouchSM_Error", "captouch_8h.html#aa5cb5202e58d86bb3d70175a4675da59", null ],
    [ "CapTouchSM_Idle", "captouch_8h.html#a8ab521b39181b03bfe856f32dc84764d", null ],
    [ "CapTouchSM_Measure", "captouch_8h.html#ab3e039fa825b6712af2695d2af840f48", null ],
    [ "CapTouchUpdateSensorReadings", "captouch_8h.html#ac290dcecf5be6aac40378cb477fc41d0", null ],
    [ "u8CapTouchGetSliderValue", "captouch_8h.html#a42c60956621c664eee5a1ebb2c1771f6", null ]
];