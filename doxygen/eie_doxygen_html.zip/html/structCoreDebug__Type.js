var structCoreDebug__Type =
[
    [ "DCRDR", "structCoreDebug__Type.html#a5bcffe99d1d5471d5e5befbc6272ebf0", null ],
    [ "DCRSR", "structCoreDebug__Type.html#a7b49cb58573da77cc8a83a1b21262180", null ],
    [ "DEMCR", "structCoreDebug__Type.html#a6cdfc0a6ce3e988cc02c2d6e8107d193", null ],
    [ "DHCSR", "structCoreDebug__Type.html#a39bc5e68dc6071187fbe2348891eabfa", null ]
];