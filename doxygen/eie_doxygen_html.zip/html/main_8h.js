var main_8h =
[
    [ "_APPLICATION_FLAGS_ADC", "main_8h.html#a965e900c8f31c6fc397d4c8f68006ddf", null ],
    [ "_APPLICATION_FLAGS_ANT", "main_8h.html#a99e01fb816763bbcc709885040976219", null ],
    [ "_APPLICATION_FLAGS_BUTTON", "main_8h.html#a9875edb821a8db4c05514204d4b00019", null ],
    [ "_APPLICATION_FLAGS_DEBUG", "main_8h.html#ac342d44eff0059984716d12e24a09f94", null ],
    [ "_APPLICATION_FLAGS_LCD", "main_8h.html#afe447de9fe6067383d4b166f2d767b44", null ],
    [ "_APPLICATION_FLAGS_LED", "main_8h.html#af384160a5b5e12e6644d05e6d4c451f6", null ],
    [ "_APPLICATION_FLAGS_TIMER", "main_8h.html#a3c44ff11e0761641d9aab70449cbe9fc", null ],
    [ "_SYSTEM_CLOCK_NO_STOP_DEBUG", "main_8h.html#ad9538b5ed34bdd70c07ea70a0952320f", null ],
    [ "_SYSTEM_CLOCK_NO_STOP_LEDS", "main_8h.html#a93b9756c0e3a27d0fc80ff7aeba8e90c", null ],
    [ "_SYSTEM_CLOCK_NO_STOP_USER", "main_8h.html#a52324d119ef161fb6f31538aafa03739", null ],
    [ "_SYSTEM_CLOCK_OSC_FAIL", "main_8h.html#a61b79bf682e89705ba3bbd79ef6a108d", null ],
    [ "_SYSTEM_CLOCK_PLL_NO_LOCK", "main_8h.html#ab6f4a6ba519a5c832853456a028cffb5", null ],
    [ "_SYSTEM_INITIALIZING", "main_8h.html#a09d1f9c845f59dd8915613bc86cbe8a2", null ],
    [ "_SYSTEM_SLEEPING", "main_8h.html#afd9f2219cf88e4531c267363ad62a1c0", null ],
    [ "_SYSTEM_STARTUP_NO_ANT", "main_8h.html#a75e1dd2be224f784012245ce6fc243f6", null ],
    [ "_SYSTEM_TIME_WARNING", "main_8h.html#aabc11530ba56383b4661a5223ceafd22", null ],
    [ "FIRMWARE_MAIN_REV", "main_8h.html#a5670ed052b79d0f8b2ac103790453a5f", null ],
    [ "FIRMWARE_SUB_REV1", "main_8h.html#a61b85219c65e9017a48dab0668c18163", null ],
    [ "FIRMWARE_SUB_REV2", "main_8h.html#ab8686aae46d43769c9f6650a12a18732", null ],
    [ "FIRMWARE_VERSION", "main_8h.html#aa14dc39d52ab121ceb570f1a265385e0", null ],
    [ "MAX_TASK_NAME_SIZE", "main_8h.html#aac1863ec45e0657b2e83d26cb352853c", null ]
];