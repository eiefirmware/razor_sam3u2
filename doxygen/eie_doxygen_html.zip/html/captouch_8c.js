var captouch_8c =
[
    [ "GET_ROTOR_SLIDER_POSITION", "captouch_8c.html#abf3df8498592c90d0a9225af39eadb4d", null ],
    [ "GET_SENSOR_STATE", "captouch_8c.html#aaf7a2690172f52b1994a1bb6adef6ed3", null ],
    [ "CaptouchCurrentHSlidePosition", "captouch_8c.html#af023afe52ae5995776797bc77a7c53a5", null ],
    [ "CaptouchCurrentVSlidePosition", "captouch_8c.html#a05197b02c441eb6eadef1ef094dd56e9", null ],
    [ "CapTouchInitialize", "captouch_8c.html#ad549ea879c9ea33b499455fcfbbd3598", null ],
    [ "CapTouchOff", "captouch_8c.html#a58fac143e9a21e91e7b789888eeec3a1", null ],
    [ "CapTouchOn", "captouch_8c.html#ac0dcd1817bb72731cd0e89f1d16f2c71", null ],
    [ "CapTouchRunActiveState", "captouch_8c.html#a89acaf27b5e59d994e64ff5c526ff2e6", null ],
    [ "CapTouchSM_Idle", "captouch_8c.html#a8ab521b39181b03bfe856f32dc84764d", null ],
    [ "CapTouchSM_Measure", "captouch_8c.html#ab3e039fa825b6712af2695d2af840f48", null ],
    [ "CapTouchUpdateSensorReadings", "captouch_8c.html#abbdc5857806e3fa99c667677217539ff", null ],
    [ "u8CapTouchGetSliderValue", "captouch_8c.html#a42c60956621c664eee5a1ebb2c1771f6", null ],
    [ "G_u32ApplicationFlags", "captouch_8c.html#a633c00979917e136ecca6a4c6be2792d", null ],
    [ "G_u32DebugFlags", "captouch_8c.html#a089097107f68be64fee27f13f5da8646", null ],
    [ "G_u32SystemFlags", "captouch_8c.html#a8744f5867dbc6c175c029dd7ee5e70af", null ],
    [ "G_u32SystemTime1ms", "captouch_8c.html#aa146f1e0ff7266bfbef420b6fc072f80", null ],
    [ "G_u32SystemTime1s", "captouch_8c.html#a0d1ec61cf0423379d45262186ed60d9c", null ],
    [ "qt_measure_data", "captouch_8c.html#a94e193b46fa38003ac824820f7e20451", null ]
];