var dir_672a85f87a0057168b63390db844f43d =
[
    [ "touch_api.h", "touch__api_8h_source.html", null ],
    [ "touch_qt_config.h", "touch__qt__config_8h_source.html", null ]
];