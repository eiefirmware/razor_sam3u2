var buttons_8h =
[
    [ "ButtonStatusType", "structButtonStatusType.html", "structButtonStatusType" ],
    [ "U32_DEBOUNCE_TIME", "buttons_8h.html#af9285c6b09a98c15907c46ed522b0903", null ],
    [ "ButtonStateType", "buttons_8h.html#a81fecba178359625b658b48652391854", [
      [ "RELEASED", "buttons_8h.html#a81fecba178359625b658b48652391854aa38d18fe73a7fc82c112b6917d0b5cd0", null ],
      [ "PRESSED", "buttons_8h.html#a81fecba178359625b658b48652391854a5ef9a100ac8b4b8d6dec477c377b7901", null ]
    ] ],
    [ "ButtonAcknowledge", "buttons_8h.html#a95ad4b3a74e234bbc6ac39ee75abd76a", null ],
    [ "ButtonInitialize", "buttons_8h.html#aa08305782ba8330decd7b853f6a8ef71", null ],
    [ "ButtonRunActiveState", "buttons_8h.html#a6d3e498637bb9cedeb3da5317180a3fe", null ],
    [ "ButtonStartDebounce", "buttons_8h.html#a082b690dd32855ece49286db4c080a1b", null ],
    [ "IsButtonHeld", "buttons_8h.html#a33a6b74e0350a30b341c8f1dff1e4f98", null ],
    [ "IsButtonPressed", "buttons_8h.html#ae03bcbd16166e9cac7cc9ab8a7bd697b", null ],
    [ "WasButtonPressed", "buttons_8h.html#a0d6b76ca5a4e523fa9995168c4742d7e", null ]
];