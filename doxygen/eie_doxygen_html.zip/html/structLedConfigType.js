var structLedConfigType =
[
    [ "eActiveState", "structLedConfigType.html#a4242490b118297b98bf9a8419060dab2", null ],
    [ "eCurrentDuty", "structLedConfigType.html#af3716d3a20359fc32353e76bf5bdb6eb", null ],
    [ "eMode", "structLedConfigType.html#a75189baaedce42a33916c58cd4f8259d", null ],
    [ "ePort", "structLedConfigType.html#a1f4d1e787195bba047333e6c39d554e2", null ],
    [ "eRate", "structLedConfigType.html#a11acb17ed0b5b0430a6f2c1391cd6111", null ],
    [ "u16Count", "structLedConfigType.html#aceade36f136a3b4c30c3a467f7c98b50", null ]
];