var structInterruptType__Type =
[
    [ "ICTR", "structInterruptType__Type.html#a5bb2c6795b90f12077534825cc844b56", null ],
    [ "RESERVED0", "structInterruptType__Type.html#af86c61a5d38a4fc9cef942a12744486b", null ],
    [ "RESERVED1", "structInterruptType__Type.html#ac4ac04e673b5b8320d53f7b0947db902", null ]
];