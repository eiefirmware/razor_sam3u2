var structUartPeripheralType =
[
    [ "fnRxCallback", "structUartPeripheralType.html#a3676f6e1b38c4de853f8c12adc895075", null ],
    [ "pBaseAddress", "structUartPeripheralType.html#a8114fd7dd814a2dc4b585e7d4ebd4922", null ],
    [ "psTransmitBuffer", "structUartPeripheralType.html#ab050493c2ee33d0b4525999076d8bbe6", null ],
    [ "pu8CurrentTxData", "structUartPeripheralType.html#a37d6782344fe4a6866def37b345f3361", null ],
    [ "pu8RxBuffer", "structUartPeripheralType.html#a90b4f2c98ae95b888a185b7d842f52b5", null ],
    [ "pu8RxNextByte", "structUartPeripheralType.html#a1b230962c18dd9d7bceac40742e28ad5", null ],
    [ "u16RxBufferSize", "structUartPeripheralType.html#ab7fc4919ed52c499554e6a111ff03385", null ],
    [ "u32CurrentTxBytesRemaining", "structUartPeripheralType.html#aba7dde0373af6515f1ea1fb3ca60b0b7", null ],
    [ "u32PrivateFlags", "structUartPeripheralType.html#a92ea6e492759d5d2e4b46c21ed300e4c", null ],
    [ "u8Pad", "structUartPeripheralType.html#a095538a86db156105d1920856af97f8b", null ],
    [ "u8PeripheralId", "structUartPeripheralType.html#a6d47610e17bac3adaae644e2f1abd6ce", null ]
];