var structqt__lib__sig__info__t =
[
    [ "lib_sig_hword", "structqt__lib__sig__info__t.html#aac182e6653ef2ed38100815b3cb0747b", null ],
    [ "lib_sig_lword", "structqt__lib__sig__info__t.html#aef6658fd7900b255135d48b0dfd62aa4", null ],
    [ "library_version", "structqt__lib__sig__info__t.html#a434d7c04a511997b2d83e34df1ba98c9", null ]
];