var structSpiConfigurationType =
[
    [ "eBitOrder", "structSpiConfigurationType.html#aa371d15e095f4b7f5055baa02d47f218", null ],
    [ "eSpiMode", "structSpiConfigurationType.html#a2196a8268f09468080608ed3dc0b136e", null ],
    [ "pCsGpioAddress", "structSpiConfigurationType.html#a2d4fa184a4ad668dfdff08c6b61247e0", null ],
    [ "ppu8RxNextByte", "structSpiConfigurationType.html#a53c9884c7bae33b79a958f98fc0549dd", null ],
    [ "pu8RxBufferAddress", "structSpiConfigurationType.html#ad78a33f90d38bf231bf0dc0d190016b3", null ],
    [ "SpiPeripheral", "structSpiConfigurationType.html#aebc6fcc9524b6fb8cd9d7a4768da65e4", null ],
    [ "u16RxBufferSize", "structSpiConfigurationType.html#ab7fc4919ed52c499554e6a111ff03385", null ],
    [ "u32CsPin", "structSpiConfigurationType.html#a746468875c8fa523de187aa9cba2f375", null ]
];