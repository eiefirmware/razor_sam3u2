var structMessageSlotType =
[
    [ "bFree", "structMessageSlotType.html#a291c4f9b5b616e8d9778e6cf8b02bf37", null ],
    [ "Message", "structMessageSlotType.html#a22003c10bbe064aa99437c7e1509d41e", null ]
];