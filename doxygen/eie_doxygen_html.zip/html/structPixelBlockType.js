var structPixelBlockType =
[
    [ "u16ColumnSize", "structPixelBlockType.html#affcb2f5c8ba8137e94e3bc1515fef271", null ],
    [ "u16ColumnStart", "structPixelBlockType.html#a853511b594e786b1c9ca3756b95a4f17", null ],
    [ "u16RowSize", "structPixelBlockType.html#a37ce88ce9e3407722e9e1af675ee122e", null ],
    [ "u16RowStart", "structPixelBlockType.html#a0975ffbcfaa296329eb4002728024fff", null ]
];