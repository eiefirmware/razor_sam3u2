var structtag__qt__touch__lib__config__data__t =
[
    [ "qt_di", "structtag__qt__touch__lib__config__data__t.html#a7080002c1fd95ac1fe2f3d66c53fade3", null ],
    [ "qt_drift_hold_time", "structtag__qt__touch__lib__config__data__t.html#a0d30c4d3de52bd997f7442fa9e9f1482", null ],
    [ "qt_max_on_duration", "structtag__qt__touch__lib__config__data__t.html#a6c01e30d9dc34f184cb53fbafd5373e3", null ],
    [ "qt_neg_drift_rate", "structtag__qt__touch__lib__config__data__t.html#a0a4799bcb635f1ba846f888903f7347f", null ],
    [ "qt_pos_drift_rate", "structtag__qt__touch__lib__config__data__t.html#ae8ef8138e2b17165e1fe4ee6c4625c94", null ],
    [ "qt_pos_recal_delay", "structtag__qt__touch__lib__config__data__t.html#a5d36505f0f8a97c9a6d297bae9299730", null ],
    [ "qt_recal_threshold", "structtag__qt__touch__lib__config__data__t.html#a414a9e6e10be303856469bbcb2778e62", null ]
];