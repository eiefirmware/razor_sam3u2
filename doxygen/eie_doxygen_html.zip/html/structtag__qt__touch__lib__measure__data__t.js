var structtag__qt__touch__lib__measure__data__t =
[
    [ "channel_references", "structtag__qt__touch__lib__measure__data__t.html#ab1a927724c0fddd7bd78f478e4ed1d88", null ],
    [ "channel_signals", "structtag__qt__touch__lib__measure__data__t.html#ac46c5450de6c3e5414d0c0d86da27a4f", null ],
    [ "qt_touch_status", "structtag__qt__touch__lib__measure__data__t.html#af0a4c93624ef8dc4e1acc7b9dfdaa3a9", null ]
];